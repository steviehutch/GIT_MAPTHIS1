﻿using System;

namespace MapThis1
{
	public static class Constants
	{
		// Replace strings with your Azure Mobile App endpoint.
		public static string ApplicationURL = @"https://mapthis1.azurewebsites.net";
	}
}

